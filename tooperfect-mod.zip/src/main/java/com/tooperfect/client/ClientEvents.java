package com.tooperfect.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.tooperfect.TooPerfect;
import com.tooperfect.registry.ModBlocks;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.FogRenderer;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.npc.AbstractVillager;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.material.FogType;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.client.event.RenderLivingEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = TooPerfect.MODID, value = Dist.CLIENT)
public final class ClientEvents {

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null || mc.isPaused()) return;

        int stage = ClientState.stage;
        if (stage < 0) return;

        if (ClientState.pendingEntry >= 0) {
            Thoughts.onStage(ClientState.pendingEntry);
            ClientState.pendingEntry = -1;
        }

        int before = Thoughts.typed();
        Thoughts.tick(stage, mc.crosshairPickEntity instanceof Mob);
        int after = Thoughts.typed();
        if (after > before && Thoughts.current != null) {
            char c = Thoughts.current.charAt(after - 1);
            if (c != ' ') {
                RandomSource r = mc.level.random;
                mc.level.playLocalSound(mc.player.getX(), mc.player.getY(), mc.player.getZ(),
                        SoundEvents.COMPARATOR_CLICK, SoundSource.AMBIENT, 0.1F, 1.7F + r.nextFloat() * 0.3F, false);
            }
        }

        if (inOverworld(mc)) {
            spawnAtmosphere(mc, stage);
        }
    }

    private static void spawnAtmosphere(Minecraft mc, int stage) {
        RandomSource r = mc.level.random;
        double px = mc.player.getX();
        double py = mc.player.getY();
        double pz = mc.player.getZ();

        if (stage <= 1) {
            // soft drifting petals of pollen
            if (r.nextInt(3) == 0) {
                mc.level.addParticle(ParticleTypes.SPORE_BLOSSOM_AIR,
                        px + (r.nextDouble() - 0.5D) * 20.0D, py + r.nextDouble() * 4.0D - 1.0D,
                        pz + (r.nextDouble() - 0.5D) * 20.0D, 0.0D, -0.02D, 0.0D);
            }
        } else if (stage == 2) {
            if (r.nextInt(4) == 0) {
                mc.level.addParticle(ParticleTypes.ASH,
                        px + (r.nextDouble() - 0.5D) * 24.0D, py + r.nextDouble() * 8.0D,
                        pz + (r.nextDouble() - 0.5D) * 24.0D, 0.0D, -0.02D, 0.0D);
            }
            // shards of the sky falling toward you
            if (r.nextInt(6) == 0) {
                mc.level.addParticle(new BlockParticleOption(ParticleTypes.FALLING_DUST, ModBlocks.SKY_GLASS.get().defaultBlockState()),
                        px + (r.nextDouble() - 0.5D) * 24.0D, py + 8.0D + r.nextDouble() * 8.0D,
                        pz + (r.nextDouble() - 0.5D) * 24.0D, 0.0D, -0.05D, 0.0D);
            }
        } else {
            if (r.nextInt(2) == 0) {
                mc.level.addParticle(ParticleTypes.CRIMSON_SPORE,
                        px + (r.nextDouble() - 0.5D) * 24.0D, py + r.nextDouble() * 8.0D - 2.0D,
                        pz + (r.nextDouble() - 0.5D) * 24.0D, 0.0D, -0.01D, 0.0D);
            }
        }
    }

    @SubscribeEvent
    public static void onFogColor(ViewportEvent.ComputeFogColor event) {
        int stage = ClientState.stage;
        if (stage < 2 || !inOverworld(Minecraft.getInstance())) return;
        float p = ClientState.progress;

        float mix;
        float tr;
        float tg;
        float tb;
        if (stage == 2) {
            mix = 0.5F * p; tr = 0.06F; tg = 0.03F; tb = 0.10F;
        } else if (stage == 3) {
            mix = 0.5F + 0.3F * p; tr = 0.28F; tg = 0.02F; tb = 0.02F;
        } else {
            mix = 0.9F; tr = 0.05F; tg = 0.0F; tb = 0.0F;
        }
        event.setRed(Mth.lerp(mix, event.getRed(), tr));
        event.setGreen(Mth.lerp(mix, event.getGreen(), tg));
        event.setBlue(Mth.lerp(mix, event.getBlue(), tb));
    }

    @SubscribeEvent
    public static void onFogRender(ViewportEvent.RenderFog event) {
        int stage = ClientState.stage;
        if (stage < 2 || !inOverworld(Minecraft.getInstance())) return;
        if (event.getMode() != FogRenderer.FogMode.FOG_TERRAIN) return;
        if (event.getType() != FogType.NONE) return; // leave water and lava fog alone

        float p = ClientState.progress;
        float factor;
        if (stage == 2) {
            factor = 1.0F - 0.3F * p;
        } else if (stage == 3) {
            factor = 0.7F - 0.25F * p;
        } else {
            factor = 0.42F - 0.12F * p;
        }
        float far = Math.max(24.0F, event.getFarPlaneDistance() * factor);
        float near = far * (stage == 2 ? 0.55F : 0.2F);
        event.setNearPlaneDistance(near);
        event.setFarPlaneDistance(far);
        event.setCanceled(true);
    }

    /** Mutated animals and villagers are drawn stretched tall and thin, and they twitch. */
    @SubscribeEvent
    public static void onRenderLivingPre(RenderLivingEvent.Pre<?, ?> event) {
        int stage = ClientState.stage;
        if (stage < 3) return;
        LivingEntity entity = event.getEntity();
        if (!(entity instanceof Mob mob)) return;

        boolean mutated = (mob instanceof Animal || mob instanceof AbstractVillager) && mob.isLeftHanded();
        boolean beast = mob instanceof Monster && stage >= 4;
        if (!mutated && !beast) return;

        float k = stage == 3 ? 0.2F + 0.5F * ClientState.progress : 0.7F + 0.3F * ClientState.progress;
        if (beast) k *= 0.6F;

        Minecraft mc = Minecraft.getInstance();
        float time = (mc.level != null ? mc.level.getGameTime() : 0L) + event.getPartialTick();
        float wobble = Mth.sin(time * 0.35F + mob.getId()) * 0.03F * k;

        PoseStack poseStack = event.getPoseStack();
        poseStack.scale(1.0F - 0.3F * k + wobble, 1.0F + 0.5F * k, 1.0F - 0.3F * k - wobble);
    }

    @SubscribeEvent
    public static void onLogout(ClientPlayerNetworkEvent.LoggingOut event) {
        ClientState.reset();
        Thoughts.reset();
    }

    private static boolean inOverworld(Minecraft mc) {
        return mc.level != null && mc.level.dimension() == Level.OVERWORLD;
    }

    private ClientEvents() {}
}
