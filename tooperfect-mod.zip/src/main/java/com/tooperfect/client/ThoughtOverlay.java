package com.tooperfect.client;

import java.util.Random;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraftforge.client.gui.overlay.ForgeGui;
import net.minecraftforge.client.gui.overlay.IGuiOverlay;

/** Draws the current thought as typewriter text just above the hotbar. */
public class ThoughtOverlay implements IGuiOverlay {
    private static final int[] COLORS = {0xFFF6E6, 0xE4EFCB, 0xB8C4D8, 0xD84040, 0xFF2020};
    private static final String GLITCH = "#%&@?!/\\|";

    @Override
    public void render(ForgeGui gui, GuiGraphics graphics, float partialTick, int width, int height) {
        String full = Thoughts.current;
        int stage = ClientState.stage;
        if (full == null || stage < 0) return;

        Minecraft mc = Minecraft.getInstance();
        Font font = mc.font;

        float age = Thoughts.age + partialTick;
        int chars = Math.min(full.length(), (int) (age / Thoughts.ticksPerChar));
        boolean typing = chars < full.length();

        float remaining = Thoughts.total - age;
        float fade = remaining < 25.0F ? Math.max(0.0F, remaining / 25.0F) : 1.0F;
        int alpha = (int) (fade * 255.0F);
        if (alpha < 8) return; // the font treats tiny alpha values as fully opaque

        // From stage 3 on, letters occasionally glitch. Seeded per few ticks so it doesn't shimmer every frame.
        long time = mc.level != null ? mc.level.getGameTime() / 3L : 0L;
        Random rng = new Random(time * 31L + chars);
        StringBuilder shown = new StringBuilder(full.substring(0, chars));
        if (stage >= 3) {
            double glitchChance = 0.015D * (stage - 2);
            for (int i = 0; i < shown.length(); i++) {
                if (shown.charAt(i) != ' ' && rng.nextDouble() < glitchChance) {
                    shown.setCharAt(i, GLITCH.charAt(rng.nextInt(GLITCH.length())));
                }
            }
        }

        int shakeX = 0;
        int shakeY = 0;
        if (stage >= 4) {
            shakeX = rng.nextInt(3) - 1;
            shakeY = rng.nextInt(3) - 1;
        }

        int color = (alpha << 24) | COLORS[Math.min(stage, COLORS.length - 1)];
        // Position is fixed from the full text width so the line types out left to right without jumping.
        int x = (width - font.width(full)) / 2 + shakeX;
        int y = height - 74 + shakeY;

        graphics.drawString(font, Component.literal(shown.toString()).withStyle(ChatFormatting.ITALIC), x, y, color, true);

        if (typing && (mc.level == null || (mc.level.getGameTime() / 5L) % 2L == 0L)) {
            graphics.drawString(font, "_", x + font.width(shown.toString()), y, color, true);
        }
    }
}
