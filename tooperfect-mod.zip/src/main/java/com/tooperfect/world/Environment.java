package com.tooperfect.world;

import java.util.List;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;

/** Time of day, weather and ambient sounds for each stage. */
public final class Environment {

    public static void tickTime(ServerLevel level, int stage) {
        long day = level.getDayTime();
        long t = day % 24000L;
        long base = day - t;
        long target = -1L;
        switch (stage) {
            case 0 -> {
                // Never let the night come: skip from dusk straight to a bright morning.
                if (t > 11800L) {
                    target = base + 24000L + 700L;
                } else if (t < 500L) {
                    target = base + 700L;
                }
            }
            case 1 -> target = base + 6000L;   // the sun stops at noon
            case 3 -> target = base + 12800L;  // frozen blood-red dusk
            case 4 -> target = base + 18000L;  // midnight, forever
            default -> { }
        }
        if (target >= 0L && target != day) {
            level.setDayTime(target);
        }
    }

    public static void tickSecond(ServerLevel level, List<ServerPlayer> players, int stage) {
        if (stage <= 2 && (level.isRaining() || level.isThundering())) {
            level.setWeatherParameters(24000, 0, false, false);
        }
        RandomSource r = level.random;
        for (ServerPlayer p : players) {
            switch (stage) {
                case 1 -> {
                    if (r.nextInt(70) == 0) play(level, p, SoundEvents.ENDERMAN_STARE, 0.3F, 0.5F);
                }
                case 2 -> {
                    if (r.nextInt(18) == 0) play(level, p, SoundEvents.GLASS_BREAK, 0.6F, 0.4F + r.nextFloat() * 0.2F);
                }
                case 3 -> {
                    if (r.nextInt(8) == 0) play(level, p, SoundEvents.WARDEN_HEARTBEAT, 0.8F, 0.9F);
                }
                case 4 -> {
                    if (r.nextInt(3) == 0) play(level, p, SoundEvents.WARDEN_HEARTBEAT, 1.0F, 0.8F + r.nextFloat() * 0.2F);
                    if (r.nextInt(30) == 0) play(level, p, SoundEvents.ENDERMAN_SCREAM, 0.5F, 0.4F);
                }
                default -> { }
            }
        }
    }

    private static void play(ServerLevel level, ServerPlayer p, SoundEvent sound, float volume, float pitch) {
        RandomSource r = level.random;
        double x = p.getX() + (r.nextDouble() - 0.5D) * 20.0D;
        double y = p.getY() + (r.nextDouble() - 0.5D) * 6.0D;
        double z = p.getZ() + (r.nextDouble() - 0.5D) * 20.0D;
        level.playSound(null, x, y, z, sound, SoundSource.AMBIENT, volume, pitch);
    }

    private Environment() {}
}
