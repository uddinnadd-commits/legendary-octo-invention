package com.tooperfect.world;

import com.tooperfect.TooPerfect;
import com.tooperfect.net.Network;
import com.tooperfect.net.StagePacket;
import java.util.List;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.Level;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = TooPerfect.MODID)
public final class ServerEvents {

    @SubscribeEvent
    public static void onLevelTick(TickEvent.LevelTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (!(event.level instanceof ServerLevel level)) return;
        if (level.dimension() != Level.OVERWORLD) return;

        List<ServerPlayer> players = level.players();
        if (players.isEmpty()) return; // the world only ages while someone is in it

        WorldState state = WorldState.get(level);
        state.ticks++;

        int stage = Progression.stage(state.ticks);
        float prog = Progression.progress(state.ticks);
        boolean changed = stage != Progression.currentStage;
        Progression.currentStage = stage;

        long gameTime = level.getGameTime();
        if (gameTime % 100L == 0L || changed) state.setDirty();
        if (changed || gameTime % 20L == 0L) {
            Network.sendToAll(new StagePacket(stage, prog));
        }

        Environment.tickTime(level, stage);
        if (gameTime % 20L == 0L) Environment.tickSecond(level, players, stage);
        if (gameTime % 10L == 0L) Flowers.tick(level, players, stage);
        if (gameTime % 2L == 0L) MobWatcher.tickGaze(level, players, stage);
        if (gameTime % 20L == 5L) MobWatcher.tickMutation(level, players, stage, prog);
        if (stage >= 2) SkyBreaker.tick(level, players, stage, prog);
        if (stage >= 3) Corruption.tick(level, players, stage, prog);
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer player && player.level() instanceof ServerLevel level) {
            WorldState state = WorldState.get(level);
            Network.sendTo(player, new StagePacket(Progression.stage(state.ticks), Progression.progress(state.ticks)));
        }
    }

    /** No monsters spawn while the world is still peaceful. */
    @SubscribeEvent
    public static void onEntityJoin(EntityJoinLevelEvent event) {
        if (event.getLevel().isClientSide() || event.loadedFromDisk()) return;
        int stage = Progression.currentStage;
        if (stage < 0 || stage > 1) return;
        if (event.getEntity() instanceof Monster && !event.getEntity().hasCustomName()) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent event) {
        Progression.currentStage = -1;
    }

    private ServerEvents() {}
}
