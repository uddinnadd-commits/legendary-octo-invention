package com.tooperfect.world;

import com.tooperfect.Config;
import net.minecraft.util.Mth;

/**
 * Stages: 0 Serenity, 1 Too Perfect, 2 Fracture (sky), 3 Decay (grass, trees, mobs), 4 Unmaking (every block).
 */
public final class Progression {
    public static final int MAX_STAGE = 4;
    public static final String[] NAMES = {"Serenity", "Too Perfect", "Fracture", "Decay", "Unmaking"};

    /** Last stage computed by the server tick (-1 until a world is ticking). */
    public static volatile int currentStage = -1;

    public static long stageTicks() {
        return Math.max(20L, (long) (Config.STAGE_MINUTES.get() * 60.0D * 20.0D));
    }

    public static int stage(long ticks) {
        return (int) Math.min((long) MAX_STAGE, ticks / stageTicks());
    }

    /** 0..1 progress through the current stage (stage 4 simply saturates after one stage length). */
    public static float progress(long ticks) {
        long st = stageTicks();
        long into = ticks - (long) stage(ticks) * st;
        return Mth.clamp((float) into / (float) st, 0.0F, 1.0F);
    }

    private Progression() {}
}
