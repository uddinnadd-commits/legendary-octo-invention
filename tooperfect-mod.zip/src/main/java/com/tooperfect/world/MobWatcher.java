package com.tooperfect.world;

import com.tooperfect.Config;
import java.util.List;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.npc.AbstractVillager;
import net.minecraft.world.phys.AABB;

/**
 * Every mob near a player turns its head to stare. From stage 1 they face you with their whole body and freeze.
 * From stage 3 they start to mutate, and mutated animals hunt the player.
 */
public final class MobWatcher {
    public static final String MUTATED = "tooperfect_mutated";
    private static final String LAST_ATTACK = "tooperfect_last_attack";

    public static void tickGaze(ServerLevel level, List<ServerPlayer> players, int stage) {
        long gameTime = level.getGameTime();
        for (ServerPlayer p : players) {
            if (p.isSpectator()) continue;
            AABB box = p.getBoundingBox().inflate(32.0D);
            for (Mob mob : level.getEntitiesOfClass(Mob.class, box)) {
                if (mob instanceof EnderDragon || mob.isPassenger() || p.getVehicle() == mob) continue;

                // The peaceful stages have no monsters at all.
                if (stage <= 1 && mob instanceof Monster && !mob.hasCustomName()) {
                    mob.discard();
                    continue;
                }

                boolean mutated = mob.getPersistentData().getBoolean(MUTATED);
                double dx = p.getX() - mob.getX();
                double dy = p.getEyeY() - mob.getEyeY();
                double dz = p.getZ() - mob.getZ();
                double flat = Math.sqrt(dx * dx + dz * dz);
                float yaw = (float) (Mth.atan2(dz, dx) * (180.0D / Math.PI)) - 90.0F;
                float pitch = (float) (-(Mth.atan2(dy, flat) * (180.0D / Math.PI)));

                // Head always tracks you, even past the angle a real head could turn.
                mob.setYHeadRot(yaw);
                mob.setXRot(pitch);

                boolean peacefulWatcher = !mutated && !(mob instanceof Monster);
                if (stage >= 1 && peacefulWatcher) {
                    mob.setYRot(yaw);
                    mob.yBodyRot = yaw;
                    if (flat < 12.0D && flat > 2.5D) {
                        mob.getNavigation().stop();
                    }
                }

                if (mutated && stage >= 3 && !p.isCreative()) {
                    hunt(level, mob, p, stage, gameTime);
                }
            }
        }
    }

    private static void hunt(ServerLevel level, Mob mob, ServerPlayer p, int stage, long gameTime) {
        double distSq = mob.distanceToSqr(p);
        if (distSq > 28.0D * 28.0D) return;
        if (!(mob instanceof Monster) && (gameTime / 2L + mob.getId()) % 4L == 0L) {
            mob.getNavigation().moveTo(p, 1.4D);
        }
        if (!(mob instanceof Monster) && distSq < 3.4D && p.isAlive()) {
            long last = mob.getPersistentData().getLong(LAST_ATTACK);
            if (gameTime - last >= 20L) {
                mob.getPersistentData().putLong(LAST_ATTACK, gameTime);
                p.hurt(level.damageSources().mobAttack(mob), stage >= 4 ? 5.0F : 3.0F);
                mob.swing(InteractionHand.MAIN_HAND);
                level.playSound(null, mob.blockPosition(), SoundEvents.RAVAGER_ATTACK, SoundSource.HOSTILE, 0.6F, 1.4F);
            }
        }
    }

    public static void tickMutation(ServerLevel level, List<ServerPlayer> players, int stage, float prog) {
        if (!Config.MOB_MUTATION.get() || stage < 3) return;
        double chance = stage == 3 ? 0.01D + 0.07D * prog : 0.30D;
        for (ServerPlayer p : players) {
            AABB box = p.getBoundingBox().inflate(48.0D);
            for (Mob mob : level.getEntitiesOfClass(Mob.class, box)) {
                if (mob.getPersistentData().getBoolean(MUTATED)) continue;
                boolean candidate = mob instanceof Animal || mob instanceof AbstractVillager || mob instanceof Monster;
                if (!candidate) continue;
                if (mob instanceof TamableAnimal tame && tame.isTame()) continue;
                if (level.random.nextDouble() < chance) {
                    mutate(level, mob);
                }
            }
        }
    }

    private static void mutate(ServerLevel level, Mob mob) {
        mob.getPersistentData().putBoolean(MUTATED, true);
        if (mob instanceof Monster) {
            int forever = 20 * 60 * 60 * 24;
            mob.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, forever, 0, false, false));
            mob.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, forever, 0, false, false));
        } else {
            // Left-handed is the flag the client reads to draw this mob stretched and wrong.
            mob.setLeftHanded(true);
        }
        level.sendParticles(ParticleTypes.LARGE_SMOKE, mob.getX(), mob.getY() + mob.getBbHeight() * 0.5D, mob.getZ(),
                12, 0.3D, 0.4D, 0.3D, 0.02D);
        level.playSound(null, mob.blockPosition(), SoundEvents.ENDERMAN_SCREAM, SoundSource.HOSTILE, 0.5F, 0.4F);
    }

    private MobWatcher() {}
}
