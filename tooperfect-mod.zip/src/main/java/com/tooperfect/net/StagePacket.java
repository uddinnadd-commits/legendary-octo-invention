package com.tooperfect.net;

import com.tooperfect.client.ClientState;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

/** Server -> client: which stage the world is in, and how far through it. */
public record StagePacket(int stage, float progress) {

    public static void encode(StagePacket packet, FriendlyByteBuf buf) {
        buf.writeVarInt(packet.stage);
        buf.writeFloat(packet.progress);
    }

    public static StagePacket decode(FriendlyByteBuf buf) {
        return new StagePacket(buf.readVarInt(), buf.readFloat());
    }

    public static void handle(StagePacket packet, Supplier<NetworkEvent.Context> context) {
        NetworkEvent.Context ctx = context.get();
        // ClientState only holds plain numbers, so it is safe to touch from either side.
        ctx.enqueueWork(() -> ClientState.apply(packet.stage, packet.progress));
        ctx.setPacketHandled(true);
    }
}
