package com.tooperfect.block;

import net.minecraft.world.level.block.HalfTransparentBlock;

/** The black, thick void that sits above the broken glass sky. Same-block faces are culled. */
public class VoidBlock extends HalfTransparentBlock {
    public VoidBlock(Properties properties) {
        super(properties);
    }
}
